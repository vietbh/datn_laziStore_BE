
<div class="modal fade" id="addDiscModal" tabindex="-1" data-bs-backdrop="static" data-bs-keyboard="false" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered">
    <div class="modal-content">
        <div class="modal-header">
        <h5 class="modal-title">
            <?php if(isset($discount)): ?>
                Sửa mã <?php echo e($discount->discount_code, false); ?>

            <?php else: ?>
                Thêm mã giảm giá
            <?php endif; ?>
        </h5>
        <?php if(isset($discount)): ?>
            <a href="<?php echo e(route('discount.index'), false); ?>" class="btn-close" aria-label="Close"></a>
        <?php else: ?>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        <?php endif; ?>
        </div>
        <div class="modal-body p-0">
            <div class="container-fluid pt-4 px-4 mb-4" >
                <div class="row g-4">
                    <div class="col-sm-12 col-xl-12">
                        <div class="bg-light rounded h-100 p-4 text-start">
                            <form 
                            <?php if(isset($discount)): ?>
                                action="<?php echo e(route('discount.update',['id'=>$discount->id]), false); ?>"
                            <?php else: ?>
                                action="<?php echo e(route('discount.store'), false); ?>"
                            <?php endif; ?>
                            method="POST">
                                <?php echo csrf_field(); ?>
                                <?php if(isset($discount)): ?>
                                    <?php echo method_field('put'); ?>
                                <?php else: ?>
                                    <?php echo method_field('post'); ?>
                                <?php endif; ?>
                                <div class="mb-3 ">
                                    <label for="discount_code" class="form-label ">Tên mã <span class="text-danger text-small">*</span></label>
                                    <input type="text" name="discount_code" class="form-control
                                    <?php $__errorArgs = ['discount_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
                                        is-invalid
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="discount_code"
                                    <?php if(isset($discount)): ?>
                                        value="<?php echo e($discount->discount_code, false); ?>"
                                    <?php endif; ?>
                                    placeholder="Nhập tên mã và không dấu (vd:giam20k,freeshiptoanquoc,...)"
                                    aria-describedby="discount_code">
                                    <?php $__errorArgs = ['discount_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="form-text text-danger"><?php echo e($message, false); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="mb-3">
                                    <label for="discount_price" class="form-label">Số tiền giảm(đ) <span class="text-danger text-sm">(*)</span></label>
                                    <input type="text" name="discount_price" class="form-control" 
                                    autocomplete="discount_price"
                                    <?php if(isset($discount)): ?>
                                        value="<?php echo e($discount->discount_price, false); ?>"
                                    <?php endif; ?>
                                    placeholder="Nhập số tiền giảm"
                                    id="discount_price">   
                                    <?php $__errorArgs = ['discount_price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="form-text text-danger"><?php echo e($message, false); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="mb-3">
                                    <label for="discount_total" class="form-label">Số lượng</label>
                                    <input type="text" name="discount_total" class="form-control" 
                                    <?php if(isset($discount)): ?>
                                        value="<?php echo e($discount->discount_total, false); ?>"
                                    <?php endif; ?>
                                    placeholder="Nhập số lượng mã"
                                    autocomplete="discount_total"
                                    id="discount_total">   
                                    <?php $__errorArgs = ['discount_total'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="form-text text-danger"><?php echo e($message, false); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="row mb-3">
                                    <div class="col-lg-6 col-sm-12">
                                        <label for="start_date" class="form-label">Ngày bắt đầu</label>
                                        <input type="datetime-local" name="start_date" class="form-control" 
                                        <?php if(isset($discount)): ?>
                                            value="<?php echo e($discount->start_date, false); ?>"
                                        <?php endif; ?>
                                        autocomplete="start_date"
                                        id="start_date">   
                                        <?php $__errorArgs = ['start_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="form-text text-danger"><?php echo e($message, false); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="col-lg-6 col-sm-12">
                                        <label for="end_date" class="form-label">Ngày kết thúc</label>
                                        <input type="datetime-local" name="end_date" class="form-control" 
                                        <?php if(isset($discount)): ?>
                                            value="<?php echo e($discount->end_date, false); ?>"
                                        <?php endif; ?>
                                        autocomplete="end_date"
                                        id="end_date">   
                                        <?php $__errorArgs = ['end_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="form-text text-danger"><?php echo e($message, false); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                
                                <div class="mb-3">
                                    <label for="show_hide" class="form-label">Trạng thái (mặc định sẽ là Hiện)</label>
                                    <select class="form-select" name="show_hide" 
                                    <?php if(isset($discount)): ?>
                                        value="<?php echo e($discount->show_hide, false); ?>"
                                    <?php endif; ?>
                                    id="show_hide">
                                        <option value='1' >Hiện</option>
                                        <option value='0' >Ẩn</option>
                                    </select>
                                </div>
                                <div class="mb-3 float-end ">
                                    <button type="submit" class="btn btn-primary">
                                    <?php if(isset($discount)): ?>
                                        Sửa
                                    <?php else: ?>
                                        Thêm mới
                                    <?php endif; ?>
                                    </button>
                                    <?php if(isset($discount)): ?>
                                        <a href="<?php echo e(route('discount.index'), false); ?>" class="btn btn-danger">Đóng</a>
                                    <?php else: ?>
                                        <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Đóng</button>
                                    <?php endif; ?>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    </div>
</div>
<?php /**PATH C:\Users\Do Trong Nhan\Downloads\datn_laziStore_BE_new\datn_laziStore_BE\resources\views/layouts/admin/components/discountModal.blade.php ENDPATH**/ ?>