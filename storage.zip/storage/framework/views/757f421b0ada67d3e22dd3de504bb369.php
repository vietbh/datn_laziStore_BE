<!doctype html>
<html lang="vi">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="x-ua-compatible" content="ie=edge">
        <title>Trang tin tức🆕 Lazi Store Page</title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        
		

		<!-- CSS here -->
        <link href="<?php echo e(asset('news/assets/assets/css/style.css'), false); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('news/assets/assets/css/bootstrap.min.css'), false); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('news/assets/assets/css/owl.carousel.min.css'), false); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('news/assets/assets/css/ticker-style.css'), false); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('news/assets/assets/css/flaticon.css'), false); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('news/assets/assets/css/slicknav.css'), false); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('news/assets/assets/css/animate.min.css'), false); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('news/assets/assets/css/magnific-popup.css'), false); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('news/assets/assets/css/fontawesome-all.min.css'), false); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('news/assets/assets/css/themify-icons.css'), false); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('news/assets/assets/css/slick.css'), false); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('news/assets/assets/css/nice-select.css'), false); ?>" rel="stylesheet">
           
   </head>

   <body>
       
    <!-- Preloader Start -->
     
    <!-- Preloader Start -->

    <header>
        <!-- Header Start -->
       <div class="header-area">
            <div class="main-header ">
                <div class="header-top black-bg d-none d-md-block">
                   <div class="container">
                       <div class="col-xl-12">
                            <div class="row d-flex justify-content-between align-items-center">
                                <div class="header-info-left">
                                    <ul>     
                                        <li><img src="<?php echo e(asset('news/assets/assets/img/icon/header_icon1.png'), false); ?>" alt="">27ºc, Sunny </li>
                                        <li><img src="<?php echo e(asset('news/assets/assets/img/icon/header_icon1.png'), false); ?>" alt=""><script>document.write(new Date().toLocaleString());</script></li>
                                    </ul>
                                </div>
                                <div class="header-info-right">
                                    <ul class="header-social">    
                                        <li><a href="#"><i class="fab fa-twitter"></i></a></li>
                                        <li><a href="#"><i class="fab fa-instagram"></i></a></li>
                                       <li> <a href="#"><i class="fab fa-pinterest-p"></i></a></li>
                                    </ul>
                                </div>
                            </div>
                       </div>
                   </div>
                </div>
                <div class="header-mid d-none d-md-block">
                   <div class="container">
                        <div class="row d-flex align-items-center">
                            <!-- Logo -->
                            <div class="col-xl-3 col-lg-3 col-md-3">
                                <div class="logo ">
                                    <a class="d-flex align-items-center text-decoration-none" href="<?php echo e(route('newsFront.index'), false); ?>">
                                            <img src="<?php echo e(asset('news/assets/upload/images/Logo-Tinh-Ba-Ria-Vung-Tau.png'), false); ?>" width="50" height="50">
                                            <h4 class="text-secondary text-bolder ">Lazi Store</h4>
                                    </a>
                                </div>
                            </div>
                            <div class="col-xl-9 col-lg-9 col-md-9">
                                <div class="header-banner f-right ">
                                    <img src="news/assets/assets/img/hero/header_card.jpg" alt="">
                                </div>
                            </div>
                        </div>
                   </div>
                </div>
               <div class="header-bottom header-sticky">
                    <div class="container">
                        <div class="row align-items-center">
                            <div class="col-xl-10 col-lg-10 col-md-12 header-flex">
                                <!-- sticky -->
                                    <div class="sticky-logo">
                                        <a href="<?php echo e(route('newsFront.index'), false); ?>">
                                            <img src="<?php echo e(asset('news/assets/upload/images/Logo-Tinh-Ba-Ria-Vung-Tau.png'), false); ?>" width="50" height="50" alt="">
                                            <h4 class="text-secondary text-bolder">Lazi Store</h4>
                                        </a>
                                    </div>
                                <!-- Main-menu -->
                                    <?php echo $__env->make('FrontEnd.part.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                         </div>
                    </div>
               </div>
            </div>
       </div>
        <!-- Header End -->
    </header>
<main>
    <?php echo $__env->yieldContent('content'); ?>
</main>
    
    <footer>
       <!-- Footer Start-->
       <div class="footer-area footer-padding fix">
            <div class="container">
                <div class="row d-flex justify-content-between">
                    <div class="col-xl-5 col-lg-5 col-md-7 col-sm-12">
                        <div class="single-footer-caption">
                            <div class="single-footer-caption">
                                <!-- logo -->
                                <div class="footer-logo">
                                    
                                    <a href="<?php echo e(route('newsFront.index'), false); ?>"><h4 class="text-warning"><img src="<?php echo e(asset('upload/images/Logo-Tinh-Ba-Ria-Vung-Tau.png'), false); ?>" width="70" height="70" alt=""> Lazi Store Page</h4></a>
                                </div>
                                <div class="footer-tittle">
                                    <div class="footer-pera">
                                        <p>Suscipit mauris pede for con sectetuer sodales adipisci for cursus fames lectus tempor da blandit gravida sodales  Suscipit mauris pede for con sectetuer sodales adipisci for cursus fames lectus tempor da blandit gravida sodales  Suscipit mauris pede for sectetuer.</p>
                                    </div>
                                </div>
                                <!-- social -->
                                <div class="footer-social">
                                    <a href="#"><i class="fab fa-twitter"></i></a>
                                    <a href="#"><i class="fab fa-instagram"></i></a>
                                    <a href="#"><i class="fab fa-pinterest-p"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-3 col-lg-3 col-md-4  col-sm-6">
                        <div class="single-footer-caption mt-60">
                            <div class="footer-tittle">
                                <h4>Newsletter</h4>
                                <p>Heaven fruitful doesn't over les idays appear creeping</p>
                                <!-- Form -->
                                <div class="footer-form" >
                                    <div id="mc_embed_signup">
                                        <form target="_blank" action="https://spondonit.us12.list-manage.com/subscribe/post?u=1462626880ade1ac87bd9c93a&amp;id=92a4423d01"
                                        method="get" class="subscribe_form relative mail_part">
                                            <input type="email" name="email" id="newsletter-form-email" placeholder="Email Address"
                                            class="placeholder hide-on-focus" onfocus="this.placeholder = ''"
                                            onblur="this.placeholder = ' Email Address '">
                                            <div class="form-icon">
                                            <button type="submit" name="submit" id="newsletter-submit"
                                            class="email_icon newsletter-submit button-contactForm"><img src="news/assets/assets/img/logo/form-iocn.png" alt=""></button>
                                            </div>
                                            <div class="mt-10 info"></div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-3 col-lg-3 col-md-5 col-sm-6">
                        <div class="single-footer-caption mb-50 mt-60">
                            <div class="footer-tittle">
                                <h4>Map</h4>
                                <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d15673.878191566528!2d106.67631391966556!3d10.851846754502919!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!4m3!3e0!4m0!4m0!5e0!3m2!1svi!2s!4v1691591901915!5m2!1svi!2s" width="350" height="250" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
       <!-- footer-bottom aera -->
       <div class="footer-bottom-area">
           <div class="container">
               <div class="footer-border">
                    <div class="row d-flex align-items-center justify-content-between">
                        <div class="col-lg-6">
                            <div class="footer-copy-right">
                                <p>
                                    Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | This template is made with <i class="ti-heart" aria-hidden="true"></i> by <a href="#" target="_blank">BH_Ix5</a>
                                </p>
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="footer-menu f-right">
                                <ul>                             
                                    <li><a href="#">Terms of use</a></li>
                                    <li><a href="#">Privacy Policy</a></li>
                                    <li><a href="#">Contact</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
               </div>
           </div>
       </div>
       <!-- Footer End-->
   </footer>
   
	<!-- JS here -->
	
		<!-- All JS Custom Plugins Link Here here -->
        <script src="<?php echo e(asset('news/assets/assets/js/vendor/modernizr-3.5.0.min.js'), false); ?>" ></script>
        
		<!-- Jquery, Popper, Bootstrap -->
        <script src="<?php echo e(asset('news/assets/assets/js/vendor/jquery-1.12.4.min.js'), false); ?>" ></script>
        <script src="<?php echo e(asset('news/assets/assets/js/popper.min.js'), false); ?>" ></script>
        <script src="<?php echo e(asset('news/assets/assets/js/bootstrap.min.js'), false); ?>" ></script>
	    <!-- Jquery Mobile Menu -->
        <script src="<?php echo e(asset('news/assets/assets/js/jquery.slicknav.min.js'), false); ?>" ></script>
        
        
		<!-- Jquery Slick , Owl-Carousel Plugins -->
        <script src="<?php echo e(asset('news/assets/assets/js/owl.carousel.min.js'), false); ?>" ></script>
        <script src="<?php echo e(asset('news/assets/assets/js/slick.min.js'), false); ?>" ></script>
        <!-- Date Picker -->
        <script src="<?php echo e(asset('news/assets/assets/js/gijgo.min.js'), false); ?>" ></script>
		<!-- One Page, Animated-HeadLin -->
        <script src="<?php echo e(asset('news/assets/assets/js/wow.min.js'), false); ?>" ></script>
        <script src="<?php echo e(asset('news/assets/assets/js/animated.headline.js'), false); ?>" ></script>
        <script src="<?php echo e(asset('news/assets/assets/js/jquery.magnific-popup.js'), false); ?>" ></script>
        <!-- Breaking New Pluging -->
        <script src="<?php echo e(asset('news/assets/assets/js/jquery.ticker.js'), false); ?>" ></script>
        <script src="<?php echo e(asset('news/assets/assets/js/site.js'), false); ?>" ></script>
		<!-- Scrollup, nice-select, sticky -->
        <script src="<?php echo e(asset('news/assets/assets/js/jquery.scrollUp.min.js'), false); ?>" ></script>
        <script src="<?php echo e(asset('news/assets/assets/js/jquery.nice-select.min.js'), false); ?>" ></script>
        <script src="<?php echo e(asset('news/assets/assets/js/jquery.sticky.js'), false); ?>" ></script>
        <!-- contact js -->
        <script src="<?php echo e(asset('news/assets/assets/js/contact.js'), false); ?>" ></script>
        <script src="<?php echo e(asset('news/assets/assets/js/jquery.form.js'), false); ?>" ></script>
        <script src="<?php echo e(asset('news/assets/assets/js/jquery.validate.min.js'), false); ?>" ></script>
        <script src="<?php echo e(asset('news/assets/assets/js/mail-script.js'), false); ?>" ></script>
        <script src="<?php echo e(asset('news/assets/assets/js/jquery.ajaxchimp.min.js'), false); ?>" ></script>
		<!-- Jquery Plugins, main Jquery -->	
        <script src="<?php echo e(asset('news/assets/assets/js/plugins.js'), false); ?>" ></script>
        <script src="<?php echo e(asset('news/assets/assets/js/main.js'), false); ?>" ></script>
    </body>
</html><?php /**PATH C:\Users\Do Trong Nhan\Downloads\datn_laziStore_BE_new\datn_laziStore_BE\resources\views/FrontEnd/app.blade.php ENDPATH**/ ?>