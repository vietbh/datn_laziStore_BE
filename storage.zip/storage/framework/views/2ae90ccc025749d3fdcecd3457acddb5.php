<?php $__env->startSection('content'); ?>
<div class="container-fluid pt-4">
    <div class="bg-light">
        <div class="modal-body p-0">
            <div class="container-fluid pt-4 px-4 mb-4">
                <div class="row ms-3">
                    <h5>
                        <?php if(isset($new)): ?>
                            Sửa tin tức <strong><?php echo e($new->title, false); ?></strong>
                        <?php else: ?>
                            Thêm tin tức
                        <?php endif; ?>
                    </h5>
                </div>
                <div class="row g-4">
                    <div class="col-sm-12 col-xl-12">
                        <div class="bg-light rounded h-100 p-4 text-start">
                            <form 
                            <?php if(isset($new)): ?>
                                action="<?php echo e(route('news.update',['id'=>$new->id]), false); ?>"
                            <?php else: ?>
                                action="<?php echo e(route('news.store'), false); ?>"
                            <?php endif; ?>
                            method="POST" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <?php if(isset($new)): ?>
                                    <?php echo method_field('put'); ?>
                                <?php else: ?>
                                    <?php echo method_field('post'); ?>
                                <?php endif; ?>
                                <div class="row mb-3">
                                    <div class="col-sm-12 col-xl-6 mb-3">
                                        <label for="title" class="form-label ">Tiêu đề tin tức <span class="text-danger text-small">(*)</span></label>
                                        <input type="text" name="title" class="form-control <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
                                        is-invalid
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="title"
                                        <?php if(isset($new)): ?>
                                            value="<?php echo e($new->title, false); ?>"
                                        <?php endif; ?>
                                        placeholder="Nhập tên tin tức (vd:Iphone15,Samsung A23,...)"
                                        aria-describedby="title">
                                        <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="form-text text-danger"><?php echo e($message, false); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="col-sm-12 col-xl-6 mb-3">
                                        <label for="seo_keywords" class="form-label">Từ khóa SEO<span class="text-danger text-small">(*)</span></label>
                                        <input type="text" name="seo_keywords" class="form-control" 
                                        <?php if(isset($new)): ?>
                                            value="<?php echo e($new->seo_keywords, false); ?>"
                                        <?php endif; ?>
                                        placeholder="Vui lòng nhập trường này"
                                        id="seo_keywords">   
                                        <?php $__errorArgs = ['seo_keywords'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div id="seo_keywords" class="form-text text-danger"><?php echo e($message, false); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="row mb-3">
                                    <div class="col-sm-12 col-xl-6 mb-3">
                                        <label for="author" class="form-label ">Tác giả<span class="text-danger text-small">(*)</span></label>
                                        <input class="form-control 
                                        <?php $__errorArgs = ['author'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
                                        is-invalid
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                        name="author" 
                                        <?php if(isset($new)): ?>
                                            value="<?php echo e($new->author, false); ?>"
                                        <?php endif; ?>
                                        autocomplete="author"
                                        placeholder="Vui lòng nhập tên tác giả"
                                        id="author" />
                                        <?php $__errorArgs = ['author'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="form-text text-danger"><?php echo e($message, false); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="col-sm-12 col-xl-6 mb-3">
                                        <label for="categories_news_id" class="form-label ">Danh mục bài viết <span class="text-danger text-small">(*)</span></label>
                                        <select class="form-select  
                                        <?php $__errorArgs = ['categories_news_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
                                        is-invalid
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="categories_news_id" 
                                        <?php if(isset($new)): ?>
                                            value="<?php echo e($new->categories_news_id, false); ?>"
                                        <?php endif; ?>
                                        id="categories_product_id">
                                            
                                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($category->id, false); ?>"><?php echo e($category->name, false); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <?php $__errorArgs = ['categories_product_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div id="categories_product_id" class="form-text text-danger"><?php echo e($message, false); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <?php if(isset($new)): ?>
                                        <div class="col-sm-12 col-xl-12 mb-3">
                                            <div class="table-responsive">
                                                <table class="table table-hover">
                                                    <thead>
                                                        <tr>
                                                          <th scope="col">Tag</th>
                                                          <th scope="col">Action</th>
                                                        </tr>
                                                      </thead>
                                                      <tbody>
                                                        <?php $__currentLoopData = $new->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tagRelaNew): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <tr>
                                                                <td><?php echo e($tagRelaNew->tag->name, false); ?></td>
                                                                <td>
                                                                    <form action="<?php echo e(route('news.remove', ['id'=>$tagRelaNew->id,'news'=>$tagRelaNew->news_id]), false); ?>" method="post">
                                                                        <?php echo csrf_field(); ?>
                                                                        <?php echo method_field('delete'); ?>
                                                                        <button type="submit" class="btn btn-danger btn-sm"><i class="far fa-trash-alt"></i></button>
                                                                    </form>
                                                                </td>
                                                            </tr>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </table>
                                            </div>
                                        </div>
                                    
                                    <?php endif; ?>
                                    <div class="col-sm-12 col-xl-12 mb-3">
                                        <label for="tag_id" class="form-label ">Tag <span class="text-danger text-small">(*)</span></label>
                                        <!-- Multiple Select -->
                                        <select class="js-example-basic-multiple" name="tag_id[]" multiple="multiple">
                                        </select>
                                        <?php $__errorArgs = ['tag_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="form-text text-danger"><?php echo e($message, false); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> 
                                    </div>
                                </div>
                                <div class="row mb-3">
                                    <div class="col-sm-12 col-xl-12 mb-3">
                                        <?php if(isset($new)): ?>
                                            <div class="mb-3"><img class="img_fluid" width='250' src="<?php echo e($new->image_url, false); ?>" alt=""></div>
                                        <?php endif; ?>
                                        <label for="image_url" class="form-label ">Chọn hình ảnh <span class="text-danger text-small">(*)</span></label>
                                        <div class="d-flex justify-content-around">
                                            <input type="file" name="image_url"
                                            class="form-control 
                                            <?php $__errorArgs = ['image_url'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
                                                is-invalid
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            id="image_url"
                                            <?php if(isset($new)): ?>
                                                value="<?php echo e($new->image_url, false); ?>"
                                            <?php endif; ?>
                                            aria-describedby="image_url">
                                            <?php $__errorArgs = ['image_url'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div id="image_url" class="form-text text-danger"><?php echo e($message, false); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            <button type="button" class="btn btn-secondary ms-1">Thêm</button>
                                        </div>
                                    </div>
                                    <div class="col-sm-12 col-xl-12 mb-3">
                                        <label for="show_hide" class="form-label">Trạng thái (mặc định sẽ là Hiện)</label>
                                        <select class="form-select" name="show_hide" 
                                        <?php if(isset($new)): ?>
                                            value="<?php echo e($new->show_hide, false); ?>"
                                        <?php endif; ?>
                                        id="show_hide">
                                            <option value="1">Hiện</option>
                                            <option value="0">Ẩn</option>
                                        </select>    
                                    </div>
                                </div>    
                                <div class="row mb-3">
                                    <div class="col-sm-12 col-xl-12">
                                        <label for="description" class="form-label">Mô tả tin tức</label>
                                        <textarea name="description" 
                                        class="form-control ck-editor__editable_inline" 
                                        id="description">
                                            <?php if(isset($new)): ?>
                                                <?php echo e($new->description, false); ?>

                                            <?php endif; ?>
                                        </textarea>
                                    </div>
                                </div>     
                                <div class=" mb-3 float-end">
                                    <button type="submit" class="btn btn-primary">
                                        <?php if(isset($new)): ?>
                                        Sửa
                                    <?php else: ?>
                                        Thêm mới
                                    <?php endif; ?>
                                    </button>
                                    <a href="<?php echo e(route('news.index'), false); ?>" class="btn btn-danger">Đóng</a>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<?php echo $__env->make('layouts.admin.News.multiSelect', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.admin.News.ckeditor', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Do Trong Nhan\Downloads\datn_laziStore_BE_new\datn_laziStore_BE\resources\views/layouts/admin/News/store.blade.php ENDPATH**/ ?>