
<div class="modal fade" id="addCategoriesModal" tabindex="-1" data-bs-backdrop="static" data-bs-keyboard="false" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered">
    <div class="modal-content">
        <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">
                <?php if(isset($category)): ?>
                    Sửa danh mục sản phẩm <?php echo e($category->name, false); ?>

                <?php else: ?>
                    Thêm danh mục sản phẩm
                <?php endif; ?>
            </h5>
            <?php if(isset($category)): ?>
                <a href="<?php echo e(route('product.cat.index'), false); ?>" class="btn-close" aria-label="Close">
                </a>
            <?php else: ?>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            <?php endif; ?>
        </div>
        <div class="modal-body p-0">
            <div class="container-fluid pt-4 px-4 mb-4" >
                <div class="row g-4">
                    <div class="col-sm-12 col-xl-12">
                        <div class="bg-light rounded h-100 p-4 text-start">
                            <form 
                            <?php if(isset($category)): ?>
                                action="<?php echo e(route('product.cat.update',['id'=>$category->id]), false); ?>"
                            <?php else: ?>
                                action="<?php echo e(route('product.cat.store'), false); ?>"
                            <?php endif; ?>
                            method="POST">
                                <?php echo csrf_field(); ?>
                                <?php if(isset($category)): ?>
                                    <?php echo method_field('put'); ?>
                                <?php else: ?>
                                    <?php echo method_field('post'); ?>
                                <?php endif; ?>
                                <div class="mb-3">
                                    <label for="name" class="form-label ">Tên danh mục <span class="text-danger text-small">*</span></label>
                                    <input type="text" 
                                    name="name"
                                     class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
                                    is-invalid
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                    id="name"
                                    <?php if(isset($category)): ?>
                                        value="<?php echo e($category->name, false); ?>"
                                    <?php endif; ?>
                                    placeholder="Nhập tên của danh mục (vd:Đồng hồ,Laptop,...)"
                                    autocomplete="name"
                                    aria-describedby="name">
                                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="form-text text-danger"><?php echo e($message, false); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="mb-3">
                                    <label for="position" class="form-label">Thứ tự của danh mục (Mặc định là 1)</label>
                                    <input type="number" name="position" class="form-control" 
                                    <?php if(isset($category)): ?>
                                        value="<?php echo e($category->position, false); ?>"
                                    <?php else: ?>
                                        value="<?php echo e(old('position'), false); ?>"
                                    <?php endif; ?>
                                    placeholder="Nhập thứ tự hiện của danh mục"
                                    autocomplete="position"
                                    id="position">   
                                    <?php $__errorArgs = ['position'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="form-text text-danger"><?php echo e($message, false); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="mb-3">
                                    <label for="parent_id" class="form-label">Danh mục cha</label>
                                    <select class="form-select" 
                                    name="parent_id" 
                                    <?php if(isset($category)): ?>
                                        value="<?php echo e($category->parent_category_id, false); ?>"
                                    <?php endif; ?>
                                    autocomplete="parent_id"
                                    id="parent_id">
                                        <option value='' disabled selected>Chọn danh mục cha</option>
                                        <?php if(isset($categories_parent)): ?>
                                            <?php $__currentLoopData = $categories_parent; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category_parent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($category_parent->id, false); ?>"><?php echo e($category_parent->name, false); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                    </select>
                                </div>
                                <div class="mb-3">
                                    <label for="show_hide" class="form-label">Trạng thái (mặc định sẽ là Hiện)</label>
                                    <select class="form-select" name="show_hide" 
                                    <?php if(isset($category)): ?>
                                        value="<?php echo e($category->show_hide, false); ?>"
                                    <?php endif; ?>
                                    id="show_hide">
                                        <option value="1">Hiện</option>
                                        <option value="0">Ẩn</option>
                                    </select>
                                </div>
                                <div class="mb-3 float-end">
                                    <button type="submit" class="btn btn-primary">
                                        <?php if(isset($category)): ?>
                                            Sửa
                                        <?php else: ?>
                                            Thêm mới
                                        <?php endif; ?>
                                    </button>
                                    <?php if(isset($category)): ?>
                                        <a href="<?php echo e(route('product.cat.index'), false); ?>" class="btn btn-danger">
                                            Đóng
                                        </a>
                                    <?php else: ?>
                                        <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Đóng</button>
                                    <?php endif; ?>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    </div>
</div>
<?php /**PATH C:\Users\Do Trong Nhan\Downloads\datn_laziStore_BE_minh\datn_laziStore_BE\resources\views/layouts/admin/components/catProModal.blade.php ENDPATH**/ ?>