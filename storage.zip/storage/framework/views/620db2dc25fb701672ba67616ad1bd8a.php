<div class="container-fluid pt-4">
    <div class="bg-light rounded-top p-4">
        <div class="row">
            <div class="col-12 col-sm-6 text-center text-sm-start">
                &copy; <a href="#">Lazi-Store</a>, Cửa hàng bán thiết bị công nghệ. 
            </div>
            <div class="col-12 col-sm-6 text-center text-sm-end">
                <!--/*** This template is free as long as you keep the footer author’s credit link/attribution link/backlink. If you'd like to use the template without the footer author’s credit link/attribution link/backlink, you can purchase the Credit Removal License from "https://htmlcodex.com/credit-removal". Thank you for your support. ***/-->
                Phát triển bởi <a href="vietbh.github.io/lazi-store">Lazi Team</a>
            </br>
            
            </div>
        </div>
    </div>
</div><?php /**PATH C:\Users\Do Trong Nhan\Downloads\datn_laziStore_BE_minh\datn_laziStore_BE\resources\views/layouts/admin/components/Footer.blade.php ENDPATH**/ ?>