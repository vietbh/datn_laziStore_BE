<div class="position-fixed top-25 end-0">
    <div class="d-block me-2 mt-3 alert <?php echo e(session('error') ? 'alert-danger' : 'alert-success', false); ?> alert-dismissible fade show p-3" id="alert" role="alert">
        <div class="d-flex align-items-center">
            <i class="fa fa-exclamation-circle me-2"></i>
            <?php echo e(session('success'), false); ?>

            <?php echo e(session('error'), false); ?>

        </div>
    </div>
</div>

<?php /**PATH C:\Users\Do Trong Nhan\Downloads\datn_laziStore_BE_new\datn_laziStore_BE\resources\views/layouts/admin/components/alert.blade.php ENDPATH**/ ?>