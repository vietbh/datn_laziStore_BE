<div class="modal fade" id="<?php echo e($modal['id'], false); ?>" tabindex="-1" data-bs-backdrop="static" data-bs-keyboard="true" aria-labelledby="<?php echo e($modal['id'], false); ?>" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered">
    <div class="modal-content">
        <div class="modal-header">
            <h5 class="modal-title">
                <?php if(isset($model)): ?>
                    Sửa <?php echo e($modal['title'], false); ?>

                <?php else: ?>
                    Thêm <?php echo e($modal['title'], false); ?>

                <?php endif; ?>
            </h5>
            <?php if(isset($model)): ?>
                <a href="<?php echo e(route($modal['route']['index']), false); ?>" class="btn-close" aria-label="Close"></a>
            <?php else: ?>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            <?php endif; ?>
        </div>
        <div class="modal-body p-0">
            <div class="container-fluid pt-4 px-4 mb-4" >
                <div class="row g-4">
                    <div class="col-sm-12 col-xl-12">
                        <div class="bg-light rounded h-100 p-4 text-start">
                            <form 
                            <?php if(isset($model)): ?>
                                action="<?php echo e(route($modal['route']['update'],['id'=>$model->id]), false); ?>"
                            <?php else: ?>
                                action="<?php echo e(route($modal['route']['store']), false); ?>"
                            <?php endif; ?>
                            method="POST">
                                <?php echo csrf_field(); ?>
                                <?php if(isset($model)): ?>
                                    <?php echo method_field('put'); ?>
                                <?php else: ?>
                                    <?php echo method_field('post'); ?>
                                <?php endif; ?>
                                <?php if(isset($modal)): ?>
                                    <?php $__currentLoopData = $modal['selections']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $label =>$v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                         <?php $__currentLoopData = $v; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $name => $place): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="mb-3">
                                                <label for="<?php echo e($name, false); ?>" class="form-label "><?php echo e($label, false); ?> <span class="text-danger text-small">*</span></label>
                                                <input type="text" name="<?php echo e($name, false); ?>" class="form-control 
                                                <?php $__errorArgs = [$name];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
                                                    is-invalid
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                id="<?php echo e($name, false); ?>"
                                                <?php if(isset($model)): ?>
                                                    value="<?php echo e($model->$name, false); ?>"
                                                <?php else: ?>
                                                    value="<?php echo e(old($name), false); ?>"
                                                <?php endif; ?>
                                                placeholder="<?php echo e($place, false); ?>"
                                                autocomplete="<?php echo e($name, false); ?>"
                                                aria-describedby="<?php echo e($name, false); ?>">
                                                <?php $__errorArgs = [$name];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <div class="form-text text-danger"><?php echo e($message, false); ?></div>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>        
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                                <?php if(isset($modal['inputSelect'])): ?>
                                    <?php $__currentLoopData = $modal['inputSelect']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $label =>$v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php $__currentLoopData = $v; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $name => $place): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="mb-3">
                                                <label for="<?php echo e($name, false); ?>" class="form-label"><?php echo e($label, false); ?></label>
                                                <select class="form-select" 
                                                name="<?php echo e($name, false); ?>" 
                                                <?php if(isset($modal['model'])): ?>
                                                    value="<?php echo e($modal['model']->parent_category_id, false); ?>"
                                                <?php endif; ?>
                                                autocomplete="<?php echo e($name, false); ?>"
                                                id="<?php echo e($name, false); ?>">
                                                    <option value='' selected><?php echo e($place, false); ?></option>
                                                    <?php if(isset($categories_parent)): ?>
                                                        <?php $__currentLoopData = $categories_parent; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category_parent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($category_parent->id, false); ?>"><?php echo e($category_parent->name, false); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <?php endif; ?>
                                                </select>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                                <div class="mb-3">
                                    <label for="show_hide" class="form-label">Trạng thái (mặc định sẽ là Hiện)</label>
                                    <select class="form-select" name="show_hide" 
                                    <?php if(isset($model)): ?>
                                        value="<?php echo e($model->show_hide, false); ?>"
                                    <?php else: ?>
                                        value="<?php echo e(old('show_hide'), false); ?>"
                                    <?php endif; ?>
                                    id="show_hide">
                                        <option value="1">Hiện</option>
                                        <option value="0">Ẩn</option>
                                    </select>
                                </div>
                                <div class="mb-3 float-end ">
                                    <button type="submit" class="btn btn-primary">
                                        <?php if(isset($model)): ?>
                                            Sửa
                                        <?php else: ?>
                                            Thêm mới
                                        <?php endif; ?>
                                    </button>
                                    <?php if(isset($model)): ?>
                                        <a href="<?php echo e(route($modal['route']['index']), false); ?>" class="btn btn-danger">Đóng</a>
                                    <?php else: ?>
                                        <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Đóng</button>
                                    <?php endif; ?>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    </div>
</div>
<?php /**PATH C:\Users\Do Trong Nhan\Downloads\datn_laziStore_BE_new\datn_laziStore_BE\resources\views/layouts/admin/components/modalAdd.blade.php ENDPATH**/ ?>