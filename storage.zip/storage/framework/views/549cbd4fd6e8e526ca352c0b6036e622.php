<?php $__env->startSection('content'); ?>
   <!-- Sale & Revenue Start -->
   <div class="container-fluid pt-4 px-4">
       <div class="row g-4">
           
           <div class="col-sm-6 col-xl-4">
               <div class="bg-light rounded d-flex align-items-center justify-content-between p-4">
                   <i class="fa fa-chart-bar fa-3x text-primary"></i>
                   <div class="ms-3">
                       <p class="mb-2">Thương hiệu</p>
                       <h6 class="mb-0"><?php echo e(count($brands), false); ?></h6>
                   </div>
               </div>
           </div>
           <div class="col-sm-6 col-xl-4">
               <div class="bg-light rounded d-flex align-items-center justify-content-between p-4">
                   <i class="fa fa-chart-area fa-3x text-primary"></i>
                   <div class="ms-3">
                       <p class="mb-2">Danh mục</p>
                       <h6 class="mb-0"><?php echo e(count($categories), false); ?></h6>
                   </div>
               </div>
           </div>
           <div class="col-sm-6 col-xl-4">
               <div class="bg-light rounded d-flex align-items-center justify-content-between p-4">
                   <i class="fa fa-chart-pie fa-3x text-primary"></i>
                   <div class="ms-3">
                       <p class="mb-2">Tổng sản phẩm</p>
                       <h6 class="mb-0"><?php echo e(count($products), false); ?> sản phẩm</h6>
                   </div>
               </div>
            </div>
       </div>
   </div>
   <!-- Sale & Revenue End -->

   <!-- Table Cate Start -->
   <div class="container-fluid pt-4 px-4">
    <div class="bg-light text-center rounded p-4">
        <div class="d-flex align-items-center justify-content-between mb-4">
            <h6 class="mb-0">Tất cả sản phẩm</h6>
            <a href="<?php echo e(route('product.create'), false); ?>" class="btn btn-primary">
                Thêm sản phẩm
            </a>
        </div>
        <div class="table-responsive" style="height: 90vh">
            <table class="table text-start align-middle table-bordered table-hover mb-0" >
                <thead>
                    <tr class="text-dark">
                        <th scope="col">Tên sản phẩm</th>
                        <th scope="col">Danh mục</th>
                        <th scope="col" class="text-center">
                            Số lượng màu
                            
                        </th>
                        <th scope="col">Trạng thái</th>
                        <th scope="col">Action</th>
                    </tr>
                </thead>
                <tbody>
                 <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <tr title="<?php echo e($product->name, false); ?>">
                         <td><?php echo e($product->name, false); ?></td>
                         <td><?php echo e($product->category->name, false); ?></td>
                        <td>
                            <?php echo e(count($product->variations), false); ?>

                            
                        </td>
                         <td><?php echo e($product->show_hide ? 'Hiện':'Ẩn', false); ?></td>
                         <td>
                         <div class="d-flex justify-content-around">
                             <a class="btn btn-sm btn-primary " href="<?php echo e(route('product.edit', ['id' => $product->id]), false); ?>" title="Detail">Detail</a>
                             <form action="<?php echo e(route('product.delete', ['id' => $product->id]), false); ?>" method="POST">
                                 <?php echo csrf_field(); ?>
                                 <?php echo method_field('delete'); ?>
                                 <button class="btn btn-sm btn-danger" type="submit" title="Xóa">Xóa</button>
                             </form>
                         </div>
                         </td>
                     </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                      
                </tbody>
            </table>
        </div>
        <?php echo e($products->links('pagination::bootstrap-5'), false); ?>

    </div>
    </div>
<!-- Table Cate End -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\DA_CNTT\datn_laziStore_BE\resources\views/layouts/admin/Product/index.blade.php ENDPATH**/ ?>