<?php $__env->startSection('content'); ?>
    <div class="container-fluid pt-4">
        <div class="bg-light">
            <div class="modal-body">
                <div class="container-fluid pt-4 px-4 mb-4" >
                    <div class="row ms-3">
                        <h5>Thêm sản phẩm</h5>
                        <hr>
                    </div>
                    <div class="row g-4">
                        <div class="col-sm-12 col-xl-12">
                            <div class="bg-light rounded h-100 p-4 text-start">
                                <form 
                                action="<?php echo e(route('product.store'), false); ?>"
                                method="POST" enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('post'); ?>
                                    <div class="row mb-3">
                                        <div class="col-sm-12 col-xl-6 mb-3">
                                            <label for="name" class="form-label ">Tên sản phẩm <span class="text-danger text-small">(*)</span></label>
                                            <input type="text" name="name" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
                                            is-invalid
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="name"
                                            <?php if(isset($product)): ?>
                                                value="<?php echo e($product->name, false); ?>"
                                            <?php else: ?>
                                                value="<?php echo e(old('name'), false); ?>"        
                                            <?php endif; ?>
                                            placeholder="Nhập tên sản phẩm (vd:Iphone15,Samsung A23,...)"
                                            autocomplete="name"
                                            aria-describedby="name">
                                            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="form-text text-danger"><?php echo e($message, false); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <div class="col-sm-12 col-xl-6 mb-3">
                                            <label for="seo_keywords" class="form-label">Từ khóa SEO<span class="text-danger text-small">(*)</span></label>
                                            <input type="text" name="seo_keywords" class="form-control" 
                                            <?php if(isset($product)): ?>
                                                value="<?php echo e($product->seo_keywords, false); ?>"
                                            <?php else: ?>
                                                value="<?php echo e(old('seo_keywords'), false); ?>"        
                                            <?php endif; ?>
                                            autocomplete="seo_keywords"
                                            placeholder="Nhập từ khóa muốn SEO"
                                            id="seo_keywords">   
                                            <?php $__errorArgs = ['seo_keywords'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="form-text text-danger"><?php echo e($message, false); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="row mb-3">
                                        <div class="col-sm-12 col-xl-6 mb-3">
                                            <label for="categories_product_id" class="form-label ">Danh mục sản phẩm <span class="text-danger text-small">(*)</span></label>
                                            <select class="form-select  
                                            <?php $__errorArgs = ['categories_product_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
                                                is-invalid
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="categories_product_id" 
                                            <?php if(isset($product)): ?>
                                                value="<?php echo e($product->categories_product_id, false); ?>"
                                            <?php else: ?>
                                                value="<?php echo e(old('categories_product_id'), false); ?>"    
                                            <?php endif; ?>
                                            autocomplete="categories_product_id"
                                            id="categories_product_id">
                                                <option value="" selected disabled>Chọn danh mục sản phẩm</option>
                                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($category->id, false); ?>"><?php echo e($category->name, false); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                            <?php $__errorArgs = ['categories_product_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="form-text text-danger"><?php echo e($message, false); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <div class="col-sm-12 col-xl-6 mb-3">
                                            <label for="brand_id" class="form-label ">Thương hiệu <span class="text-danger text-small">(*)</span></label>
                                            <select class="form-select  
                                            <?php $__errorArgs = ['brand_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
                                                is-invalid
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                            name="brand_id" 
                                            <?php if(isset($product)): ?>
                                                value="<?php echo e($product->brand_id, false); ?>"
                                            <?php else: ?>
                                                value="<?php echo e(old('brand_id'), false); ?>"    
                                            <?php endif; ?>
                                            autocomplete="brand_id"
                                            id="brand_id">
                                                <option value="" selected disabled>Chọn thương hiệu sản phẩm</option>
                                                <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($brand->id, false); ?>"><?php echo e($brand->name, false); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                            <?php $__errorArgs = ['brand_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="form-text text-danger"><?php echo e($message, false); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="row mb-3">
                                        <div class="col-sm-12 col-xl-12 mb-3">
                                            <label for="show_hide" class="form-label">Trạng thái (mặc định sẽ là Hiện)</label>
                                            <select class="form-select" name="show_hide" 
                                            <?php if(isset($product)): ?>
                                                value="<?php echo e($product->show_hide, false); ?>"
                                            <?php else: ?>
                                                value="<?php echo e(old('show_hide'), false); ?>"    
                                            <?php endif; ?>
                                            autocomplete="show_hide"
                                            id="show_hide">
                                                <option value="1">Hiện</option>
                                                <option value="0">Ẩn</option>
                                            </select>    
                                        </div>
                                    </div>    
                                    <div class="row mb-3">
                                        <div class="col-sm-12 col-xl-12">
                                            <label for="description" class="form-label">Mô tả sản phẩm</label>
                                            <textarea
                                            name="description"
                                            id="description"
                                            class="form-control ck-editor__editable_inline" 
                                            autocomplete="description"
                                            >
                                                <?php if(isset($product)): ?>
                                                    <?php echo e($product->description, false); ?>

                                                <?php endif; ?>
                                            </textarea>
                                        </div>
                                    </div>   
                                    <div class="mb-3 float-end">
                                        <button type="submit" class="btn btn-primary">
                                            <?php if(isset($product)): ?>
                                                Sửa
                                            <?php else: ?>
                                                Thêm mới
                                            <?php endif; ?>
                                        </button>
                                        <?php if(isset($product)): ?>
                                            <a href="<?php echo e(route('product.index'), false); ?>" class="btn btn-danger">Đóng</a>
                                        <?php else: ?>
                                            <a href="<?php echo e(route('product.index'), false); ?>" >
                                                <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Đóng</button>
                                            </a>
                                        <?php endif; ?>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>    
    </div>    
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <?php echo $__env->make('layouts.admin.Product.ckeditor', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Do Trong Nhan\Downloads\datn_laziStore_BE_new\datn_laziStore_BE\resources\views/layouts/admin/Product/store.blade.php ENDPATH**/ ?>