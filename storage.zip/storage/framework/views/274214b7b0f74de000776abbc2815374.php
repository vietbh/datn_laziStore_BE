
<div class="modal fade" id="addPolicyModal" tabindex="-1" data-bs-backdrop="static" data-bs-keyboard="false" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered">
    <div class="modal-content">
        <div class="modal-header">
            <h5 class="modal-title">
                <?php if(isset($policy)): ?>
                    Sửa chính sách <?php echo e($policy->name, false); ?>

                <?php else: ?>
                    Thêm chính sách
                <?php endif; ?>
            </h5>
            <?php if(isset($policy)): ?>
                <a href="<?php echo e(route('policy.index'), false); ?>" class="btn-close" aria-label="Close"></a>
            <?php else: ?>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            <?php endif; ?>
        </div>
        <div class="modal-body p-0">
            <div class="container-fluid pt-4 px-4 mb-4" >
                <div class="row g-4">
                    <div class="col-sm-12 col-xl-12">
                        <div class="bg-light rounded h-100 p-4 text-start">
                            <form 
                            <?php if(isset($policy)): ?>
                                action="<?php echo e(route('policy.update',['id'=>$policy->id]), false); ?>"
                            <?php else: ?>
                                action="<?php echo e(route('policy.store'), false); ?>"
                            <?php endif; ?>
                            method="POST">
                                <?php echo csrf_field(); ?>
                                <?php if(isset($policy)): ?>
                                    <?php echo method_field('put'); ?>
                                <?php else: ?>
                                    <?php echo method_field('post'); ?>
                                <?php endif; ?>
                                <div class="mb-3">
                                    <label for="name" class="form-label ">Tên chính sách <span class="text-danger text-small">*</span></label>
                                    <input type="text" name="name" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                    id="name"
                                    <?php if(isset($policy)): ?>
                                        value="<?php echo e($policy->name, false); ?>"
                                    <?php endif; ?>
                                    placeholder="Nhập tên (vd:Chính sách bảo mật,Laptop,...)"
                                    autocomplete="name"
                                    aria-describedby="name">
                                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="form-text text-danger"><?php echo e($message, false); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="mb-3">
                                    <label for="value" class="form-label ">Nội dung <span class="text-danger text-small">*</span></label>
                                    <input type="text" name="value" class="form-control <?php $__errorArgs = ['value'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                    id="value"
                                    <?php if(isset($policy)): ?>
                                        value="<?php echo e($policy->value, false); ?>"
                                    <?php endif; ?>
                                    placeholder="Nhập tên (vd:Chính sách bảo mật,Laptop,...)"
                                    autocomplete="value"
                                    aria-describedby="value">
                                    <?php $__errorArgs = ['value'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="form-text text-danger"><?php echo e($message, false); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="mb-3">
                                    <label for="position" class="form-label">Thứ tự(Mặc định là 1)</label>
                                    <input type="number" name="position" class="form-control <?php $__errorArgs = ['position'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                    <?php if(isset($policy)): ?>
                                        value="<?php echo e($policy->position, false); ?>"
                                    <?php else: ?>
                                        value="1"
                                    <?php endif; ?>
                                    placeholder="Nhập thứ tự hiện của danh mục"
                                    autocomplete="position"
                                    id="position">   
                                    <?php $__errorArgs = ['position'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="form-text text-danger"><?php echo e($message, false); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="mb-3">
                                    <label for="show_hide" class="form-label">Trạng thái (mặc định sẽ là Hiện)</label>
                                    <select class="form-select" name="show_hide" 
                                    <?php if(isset($policy)): ?>
                                        value="<?php echo e($policy->show_hide, false); ?>"
                                    <?php endif; ?>
                                    id="show_hide">
                                        <option value="1">Hiện</option>
                                        <option value="0">Ẩn</option>
                                    </select>
                                </div>
                                <div class="mb-3 float-end">
                                    <button type="submit" class="btn btn-primary">
                                        <?php if(isset($policy)): ?>
                                            Sửa
                                        <?php else: ?>
                                            Thêm mới
                                        <?php endif; ?>
                                    </button>
                                    <?php if(isset($policy)): ?>
                                        <a href="<?php echo e(route('policy.index'), false); ?>" class="btn btn-danger">Đóng </a>
                                    <?php else: ?>
                                        <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Đóng</button>
                                    <?php endif; ?>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    </div>
</div>
<?php /**PATH C:\Users\Do Trong Nhan\Downloads\datn_laziStore_BE_new\datn_laziStore_BE\resources\views/layouts/admin/components/policyModal.blade.php ENDPATH**/ ?>