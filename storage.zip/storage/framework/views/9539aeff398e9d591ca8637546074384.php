<div class="main-menu d-none d-md-block">
    
    <nav>
        <ul id="navigation">
            <li><a href="<?php echo e(route('newsFront.index'), false); ?>">Trang chủ</a></li>
            <li><a href="#">Danh mục</a>
                <ul class="submenu">
                    <?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="nav-item">
                            
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </li>
            <li><a href="<?php echo e(route('newsFront.index', ['slug'=>1]), false); ?>">Tin ngoài nước</a></li>
            <li><a href="latest_news.html">Tin buôn bán</a></li>
            <li><a href="contact.html">Dịch vụ</a></li>
            <?php if(Auth::check()): ?>
                <li><a href="#" class="truncate">Xin chào <?php echo e(Auth::user()->name, false); ?></a>
                    <ul class="submenu">
                        <?php if(Route::has('login')): ?>
                                <?php if(auth()->guard()->check()): ?>               
                                        <li class="nav-item"> 
                                            <a href="<?php echo e(route('profile.edit'), false); ?>">Thông tin cá nhân</a>
                                        </li>
                                        <?php if(Auth::user()->role === 0): ?>
                                        <li class="nav-item"> 
                                            <a href="<?php echo e(url('/admin'), false); ?>">Admin</a>
                                        </li>
                                        <?php endif; ?>
                                        <form  style="width: 163px;height: 33px;" method="POST" action="<?php echo e(route('logout'), false); ?>">
                                            <?php echo csrf_field(); ?>
                                                <a class="my-0 ml-2 pl-1 py-1"  href="route('logout')"
                                                        onclick="event.preventDefault();
                                                                    this.closest('form').submit();">
                                                    <?php echo e(__('Đăng xuất'), false); ?>

                                                </a>
                                        </form>
                                <?php endif; ?>
                        
                        <?php endif; ?>
                    </li>
                </ul>
            <?php else: ?>
                <li><a href="#">Tài khoản</a>
                    <ul class="submenu">
                        <li class="nav-item">
                            <?php if(Route::has('login')): ?>
                                    <?php if(auth()->guard()->check()): ?>
                                        <a href="<?php echo e(url('/dashboard'), false); ?>"class="">Dashboard</a>
                                    <?php else: ?>
                                        <a href="<?php echo e(route('login'), false); ?>"class="">Đăng nhập</a>
                                        <?php if(Route::has('register')): ?>
                                            <a href="<?php echo e(route('register'), false); ?>"class="">Đăng kí</a>
                                        <?php endif; ?>
                                    <?php endif; ?>
                            
                            <?php endif; ?>

                            
                        </li>
                    </ul>
                </li>        
            <?php endif; ?>
        </ul>
    </nav>

</div>
</div>
<div class="col-xl-2 col-lg-2 col-md-4">
    <div class="header-right-btn f-right d-none d-lg-block">
        <i class="fas fa-search special-tag"></i>
        <div class="search-box">
            <form action="#">
                <input type="text" placeholder="Search">

            </form>
        </div>
    </div>
</div>
<!-- Mobile Menu -->
<div class="col-12">
    <div class="mobile_menu d-block d-md-none"></div>
</div>


<?php /**PATH C:\DA_CNTT\datn_laziStore_BE\resources\views/FrontEnd/part/nav.blade.php ENDPATH**/ ?>