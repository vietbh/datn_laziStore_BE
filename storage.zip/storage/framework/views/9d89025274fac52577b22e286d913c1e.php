<?php $__env->startSection('content'); ?>
    <div class="container-fluid mt-5 mb-5" style="height: 85vh">
        <div class="card bg-light">
            <div class="card-body p-1 m-3">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-12">
                            <nav style="--bs-breadcrumb-divider: '>';" aria-label="breadcrumb">
                                <ol class="breadcrumb">
                                  <li class="breadcrumb-item"><a href="<?php echo e(route('product.edit', ['id'=>$product->id]), false); ?>">Sản phẩm <?php echo e($product->name, false); ?></a></li>
                                  <li class="breadcrumb-item active" aria-current="page">Thêm thông số sản phẩm</li>
                                </ol>
                            </nav>
                            <h5 class="card-title my-3">
                                <?php if(isset($productSpecification)): ?>
                                    Sửa 
                                <?php else: ?>
                                    Thêm thông số <?php echo e($product->name, false); ?>

                                <?php endif; ?>
                            </h5>                 
                        </div>
                        <div class="col-sm-6 col-xl-4">
                            <div class="bg-white rounded h-100 p-3 text-start">
                                <form 
                                    <?php if(isset($productSpecification)): ?>
                                        action="<?php echo e(route('specifi.update',['id' => $productSpecification->id]), false); ?>"
                                    <?php else: ?>
                                        action="<?php echo e(route('specifi.store'), false); ?>"
                                    <?php endif; ?>
                                    method="post" enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>
                                    <?php if(isset($productSpecification)): ?>
                                        <?php echo method_field('put'); ?>
                                    <?php else: ?>   
                                        <?php echo method_field('post'); ?>
                                    <?php endif; ?>
                                    <div class="row mb-3">
                                        <div class="col-sm-12 col-xl-12 mb-3">
                                            <input type="text" value="<?php echo e($product->id, false); ?>" name="product_id" hidden>
                                            <label for="name" class="form-label">Tên thông số <span class="text-danger text-small">(*)</span></label>
                                            <input type="text" class="form-control" 
                                            name="name"
                                            <?php if(isset($productSpecification)): ?>
                                                value="<?php echo e($productSpecification->name, false); ?>"
                                            <?php else: ?>
                                                value="<?php echo e(old('name'), false); ?>"
                                            <?php endif; ?>
                                            autocomplete="name"
                                            placeholder="Kích thước màn hình,bộ nhớ,..."
                                            id="name">
                                            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="form-text text-danger"><?php echo e($message, false); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <div class="col-sm-12 col-xl-12 mb-3">
                                            <label for="value" class="form-label ">Giá trị thông số <span class="text-danger text-small">(*)</span></label>
                                            <input type="text" name="value" class="form-control 
                                            <?php $__errorArgs = ['value'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
                                                is-invalid
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="value"
                                            <?php if(isset($productSpecification)): ?>
                                                value="<?php echo e($productSpecification->value, false); ?>"
                                            <?php else: ?>
                                                value="<?php echo e(old('value'), false); ?>"
                                            <?php endif; ?>
                                            autocomplete="value"
                                            placeholder="Nhập tên thông số (vd:Công nghệ màn hình)"
                                            aria-describedby="value">
                                            <?php $__errorArgs = ['value'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="form-text text-danger"><?php echo e($message, false); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <div class="col-sm-12 col-xl-12 mb-3">
                                            <label for="position" class="form-label ">Thứ tự</label>
                                            <input type="number" name="position" class="form-control
                                            <?php $__errorArgs = ['position'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
                                                is-invalid
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="position"
                                            <?php if(isset($productSpecification)): ?>
                                                value="<?php echo e($productSpecification->position, false); ?>"
                                            <?php else: ?>
                                                value="1"
                                            <?php endif; ?>
                                            autocomplete="position"
                                            placeholder="Nhập giá trị (VD:Dynamic AMOLED 2X)"
                                            aria-describedby="position">
                                            <?php $__errorArgs = ['position'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="form-text text-danger"><?php echo e($message, false); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <div class="col-sm-12 col-xl-12 mb-3">
                                            <label for="show_hide" class="form-label">Trạng thái (mặc định sẽ là Hiện)</label>
                                            <select class="form-select" name="show_hide" 
                                            <?php if(isset($productSpecification)): ?>
                                                value="<?php echo e($productSpecification->show_hide, false); ?>"
                                            <?php else: ?>
                                                value="<?php echo e(old('show_hide'), false); ?>"    
                                            <?php endif; ?>
                                            autocomplete="show_hide"
                                            id="show_hide">
                                                <option value="1">Hiện</option>
                                                <option value="0">Ẩn</option>
                                            </select>    
                                        </div>
                                        <div class="col-sm-12 col-xl-12 mb-3">
                                            <div class="d-flex justify-content-end">
                                                <?php if(isset($productSpecification)): ?>
                                                    <button type="submit" class="btn btn-primary me-2">Sửa</button>
                                                    <a href="<?php echo e(route('specifi.create',['id' => $product->id]), false); ?>">
                                                        <button type="button" class="float-right btn btn-secondary me-2">Đóng</button>
                                                    </a>                                            
                                                <?php else: ?>
                                                    <?php if($productSpecificationCount > 0): ?>
                                                        <a href="<?php echo e(route('varia.create',['id' => $product->id ]), false); ?>">
                                                            <button type="button" class="float-right btn btn-sm btn-secondary me-2">Màu sản phẩm</button>
                                                        </a>                                            
                                                        <a href="<?php echo e(route('product.index'), false); ?>">
                                                            <button type="button" class="float-right btn btn-sm btn-secondary me-2">Đóng</button>
                                                        </a>                                            
                                                    <?php endif; ?>
                                                    <button type="submit" class="btn <?php if($productSpecificationCount > 0): ?> btn-sm <?php endif; ?> btn-primary me-2">Thêm</button>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                        <div class="col-sm-12 col-xl-8">
                            <div class="bg-white rounded h-100 p-2 text-start">
                                <div class="table-responsive">
                                    <table class="table table-striped table-hover">
                                        <thead>
                                            <tr>
                                                <th scope="col">Tên thông sô</th>
                                                <th scope="col">Giá trị thông số</th>
                                                <th scope="col">Vị trí</th>
                                                <th scope="col">Ẩn Hiện</th>
                                                <th scope="col" class="text-start" colspan="2">Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php if(isset($productSpecifications)): ?>
                                                <?php $__currentLoopData = $productSpecifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $productSpeci): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr>
                                                        <td ><p><?php echo e($productSpeci->name, false); ?></p></td>
                                                        <td ><p><?php echo e($productSpeci->value, false); ?></p></td>
                                                        <td ><p><?php echo e($productSpeci->position, false); ?></p></td>
                                                        <td ><p><?php echo e($productSpeci->show_hide ? 'Ẩn' : 'Hiện', false); ?></p></td>
                                                        <td>
                                                            <div class="d-flex justify-content-evenly">
                                                                <a class="<?php if(isset($productSpecification)): ?><?php echo e($productSpeci->id == $productSpecification->id ? 'd-none' : '', false); ?> <?php endif; ?>" href="<?php echo e(route('specifi.edit', ['id' => $productSpeci->id]), false); ?>" title="Edit"  >
                                                                        <button class="btn btn-sm btn-primary">
                                                                            Edit
                                                                        </button>
                                                                    </a>
                                                                <form action="<?php echo e(route('specifi.delete', ['id' => $productSpeci->id]), false); ?>" method="POST">
                                                                    <?php echo csrf_field(); ?>
                                                                    <?php echo method_field('delete'); ?>
                                                                    <button class="btn btn-sm btn-danger" type="submit" title="Xóa">Xóa</button>
                                                                </form>
                                                            </div>
                                                        </td>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php else: ?>
                                                <thead>
                                                    <tr>
                                                        <th scope="col">Id</th>
                                                        <th scope="col">Hình ảnh</th>
                                                        <th scope="col">Màu sắc</th>
                                                        <th scope="col">Giá</th>
                                                        <th scope="col">Giá khuyến mãi</th>
                                                        <th scope="col">Số lượng</th>
                                                        <th scope="col"></th>
                                                        <th scope="col" class="text-start" colspan="2">Action</th>
                                                        <hr>
                                                    </tr>
                                                </thead>
                                            <?php endif; ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Do Trong Nhan\Downloads\datn_laziStore_BE_minh\datn_laziStore_BE\resources\views/layouts/admin/components/speciModal.blade.php ENDPATH**/ ?>