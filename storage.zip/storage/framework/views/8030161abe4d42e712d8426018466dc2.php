<?php $__env->startSection('content'); ?>

    <!-- Trending Area Start -->
    <div class="trending-area fix">
        <div class="container">
            <div class="trending-main">
                <!-- Trending Tittle -->
                <div class="row">
                    <div class="col-lg-12">
                        <div class="py-3"></div>
                        <div class="trending-tittle">
                            <strong>Trending now</strong>
                         
                            <div class="trending-animated">
                                <ul id="js-news" class="js-hidden">
                                    <?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class="news-item"><a href="<?php echo e(route('newsFront.show', ['slug'=>$item->id]), false); ?>"><?php echo e($item->title, false); ?></a></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                            
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-8">
                        <!-- Trending Top -->
                        <div class="trending-top mb-30">
                            <div class="trend-top-img">
                                <img src="news/assets/assets/img/trending/trending_top.jpg" alt="">
                                <div class="trend-top-cap">
                                    <span>Appetizers</span>
                                    <h2><a href="details.html">Welcome To The Best Model Winner<br> Contest At Look of the year</a></h2>
                                </div>
                            </div>
                        </div>
                        <!-- Trending Bottom -->
                        <div class="trending-bottom">
                            <div class="row">
                                <?php $__empty_1 = true; $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $news): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <div class="col-lg-4">
                                        <div class="single-bottom mb-35">
                                            <div class="trend-bottom-img mb-30">
                                                <img src="<?php echo e(asset($news->image_url), false); ?> " width="200" height="200" alt="" loading="lazy">
                                            </div>
                                            <div class="trend-bottom-cap">
                                                <span class="color1"><?php echo e($news->category->name, false); ?></span>
                                                <h4><a class="a-title d-inline-block text-truncate" style="max-width: 250px;"  href="<?php echo e(route('newsFront.show',['slug' => $news->slug]), false); ?>"><?php echo e($news->title, false); ?></a></h4>
                                            </div>
                                        </div>
                                                    <p class="d-inline-block text-truncate" style="max-width: 150px;"><?php echo $news->description; ?></p>
                                        
                                                <div class="bg-secondary pl-2 rounded pb-0">
                                                    <p class="text-light ">Ngày đăng: <?php echo e($news->date_create, false); ?></p>
                                                </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <div class="col-lg-4">
                                        <div class="single-bottom mb-35">
                                            <div class="trend-bottom-img mb-30">
                                                <img src="news/assets/assets/img/trending/trending_bottom2.jpg" alt="">
                                            </div>
                                            <div class="trend-bottom-cap">
                                                <span class="color2">Sports</span>
                                                <h4><h4><a href="details.html">Tin tiếp tục cập nhật by “Mascng.”</a></h4></h4>
                                            </div>
                                        </div>
                                    </div>
                                <?php endif; ?> 

                            </div>
                        </div>
                    </div>
                    <!-- Right content -->
                    
                </div>
            </div>
        </div>
    </div>
   
    <!--  Recent Articles start -->
    <div class="recent-articles">
        <div class="container">
           <div class="recent-wrapper">
                <!-- section Tittle -->
                <div class="row">
                    <div class="col-lg-12">
                        <div class="section-tittle mt-30 mb-30">
                            <h3>Tin cua nguoi dung</h3>
                        </div>
                    </div>
                </div>
                <div class="row">
                    
                </div>
           </div>
        </div>
    </div>           
    <!--Recent Articles End -->
    
    <div class="youtube-area video-padding">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="video-items-active">
                        <div class="video-items text-center">
                            <iframe src="<?php echo e(asset('https://www.youtube.com/embed/CicQIuG8hBo'), false); ?>" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                        </div>
                        <div class="video-items text-center">
                            <iframe  src="<?php echo e(asset('https://www.youtube.com/embed/rIz00N40bag'), false); ?>" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                        </div>
                        <div class="video-items text-center">
                            <iframe src="<?php echo e(asset('https://www.youtube.com/embed/CONfhrASy44'), false); ?>" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

                        </div>
                        <div class="video-items text-center">
                            <iframe src="<?php echo e(asset('https://www.youtube.com/embed/lq6fL2ROWf8'), false); ?>" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                         
                        </div>
                        <div class="video-items text-center">
                            <iframe src="<?php echo e(asset('https://www.youtube.com/embed/0VxlQlacWV4'), false); ?>" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                        </div>
                    </div>
                </div>
            </div>
            <div class="video-info">
                <div class="row">
                    <div class="col-lg-6">
                        <div class="video-caption">
                            <div class="top-caption">
                                <span class="color1">Politics</span>
                            </div>
                            <div class="bottom-caption">
                                <h2>Welcome To The Best Model Winner Contest At Look of the year</h2>
                                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit sed do eiusmod ipsum dolor sit. Lorem ipsum dolor sit amet consectetur adipisicing elit sed do eiusmod ipsum dolor sit. Lorem ipsum dolor sit amet consectetur adipisicing elit sed do eiusmod ipsum dolor sit lorem ipsum dolor sit.</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="testmonial-nav text-center">
                            <div class="single-video">
                                <iframe  src="<?php echo e(asset('https://www.youtube.com/embed/CicQIuG8hBo'), false); ?>" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                                <div class="video-intro">
                                    <h4>Welcotme To The Best Model Winner Contest</h4>
                                </div>
                            </div>
                            <div class="single-video">
                                <iframe  src="<?php echo e(asset('https://www.youtube.com/embed/rIz00N40bag'), false); ?>" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                                <div class="video-intro">
                                    <h4>Welcotme To The Best Model Winner Contest</h4>
                                </div>
                            </div>
                            <div class="single-video">
                                <iframe src="<?php echo e(asset('https://www.youtube.com/embed/CONfhrASy44'), false); ?>" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                                <div class="video-intro">
                                    <h4>Welcotme To The Best Model Winner Contest</h4>
                                </div>
                            </div>
                            <div class="single-video">
                                <iframe src="<?php echo e(asset('https://www.youtube.com/embed/lq6fL2ROWf8'), false); ?>" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                                <div class="video-intro">
                                    <h4>Welcotme To The Best Model Winner Contest</h4>
                                </div>
                            </div>
                            <div class="single-video">
                                <iframe src="<?php echo e(asset('https://www.youtube.com/embed/0VxlQlacWV4'), false); ?>" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                                <div class="video-intro">
                                    <h4>Welcotme To The Best Model Winner Contest</h4>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div> 
    <!-- End Start youtube -->
    <!--  Recent Articles start -->
    <div class="recent-articles">
        <div class="container">
           <div class="recent-wrapper">
                <!-- section Tittle -->
                <div class="row">
                    <div class="col-lg-12">
                        <div class="section-tittle mt-30 mb-30">
                            <h3>Tin de xuat</h3>
                        </div>
                    </div>
                </div>
                <div class="row">
                    
                </div>
           </div>
        </div>
    </div>           
    <!--Recent Articles End -->
   
<?php $__env->stopSection(); ?>
<?php echo $__env->make('FrontEnd/app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Do Trong Nhan\Downloads\datn_laziStore_BE_minh\datn_laziStore_BE\resources\views/FrontEnd/News.blade.php ENDPATH**/ ?>