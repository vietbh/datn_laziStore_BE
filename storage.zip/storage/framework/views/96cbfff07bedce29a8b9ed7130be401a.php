<?php $__env->startSection('content'); ?>
    <div class="container-fluid mt-5 mb-5" style="height: 120vh">
        <div class="card bg-light">
            <div class="card-body p-1 m-3">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-12">
                            <nav style="--bs-breadcrumb-divider: '>';" aria-label="breadcrumb">
                                <ol class="breadcrumb">
                                  <li class="breadcrumb-item"><a href="<?php echo e(route('product.edit', ['id'=>$product->id]), false); ?>">Sản phẩm <?php echo e($product->name, false); ?></a></li>
                                  <li class="breadcrumb-item active" aria-current="page">Thêm màu sắc</li>
                                </ol>
                            </nav>
                            <h5 class="card-title my-3">
                                <?php if(isset($productVariation)): ?>
                                    Sửa 
                                <?php else: ?>
                                    Thêm màu sắc <?php echo e($product->name, false); ?>

                                <?php endif; ?>
                            </h5>                 
                        </div>
                        <div class="col-sm-6 col-xl-4">
                            <div class="bg-white rounded h-100 p-3 text-start">
                                <form 
                                    <?php if(isset($productVariation)): ?>
                                        action="<?php echo e(route('varia.update',['id' => $productVariation->id]), false); ?>"
                                    <?php else: ?>
                                        action="<?php echo e(route('varia.store'), false); ?>"
                                    <?php endif; ?>
                                    method="post" enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>
                                    <?php if(isset($productVariation)): ?>
                                        <?php echo method_field('put'); ?>
                                    <?php else: ?>   
                                        <?php echo method_field('post'); ?>
                                    <?php endif; ?>
                                    <div class="row mb-3">
                                        <div class="col-sm-12 col-xl-12 mb-3">
                                            <input type="text" value="<?php echo e($product->id, false); ?>" name="product_id" hidden>
                                            <label for="color_type" class="form-label">Màu sắc <span class="text-danger text-small">(*)</span></label>
                                            <input type="text" class="form-control
                                            <?php $__errorArgs = ['color_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
                                                is-invalid
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                            name="color_type"
                                            <?php if(isset($productVariation)): ?>
                                                value="<?php echo e($productVariation->color_type, false); ?>"
                                            <?php else: ?>
                                                value="<?php echo e(old('color_type'), false); ?>"
                                            <?php endif; ?>
                                            autocomplete="color_type"
                                            placeholder="Màu đen,màu vàng,..."
                                            id="color_type">
                                            <?php $__errorArgs = ['color_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="form-text text-danger"><?php echo e($message, false); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <div class="col-sm-12 col-xl-12 mb-3">
                                            <label for="price" class="form-label ">Giá gốc <span class="text-danger text-small">(*Giá tiền x 1000đ)</span></label>
                                            <input type="text" name="price" class="form-control <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
                                            is-invalid
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            id="price"
                                            <?php if(isset($productVariation)): ?>
                                                value="<?php echo e($productVariation->price / 1000, false); ?>"
                                            <?php else: ?>
                                                value="<?php echo e(old('price'), false); ?>"
                                            <?php endif; ?>
                                            autocomplete="price"
                                            placeholder="Nhập giá tiền (vd:300=300.000 vnđ)"
                                            aria-describedby="price">
                                            <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="form-text text-danger"><?php echo e($message, false); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <div class="col-sm-12 col-xl-12 mb-3">
                                            <label for="price_sale" class="form-label ">Giá khuyến mãi <span class="text-danger text-small">(*Giá tiền x 1000đ)</span></label>
                                            <input type="text" name="price_sale" class="form-control
                                            <?php $__errorArgs = ['price_sale'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
                                            is-invalid
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            id="price_sale"
                                            <?php if(isset($productVariation)): ?>
                                                value="<?php echo e($productVariation->price_sale /1000, false); ?>"
                                            <?php else: ?>
                                                value="<?php echo e(old('price_sale'), false); ?>"
                                            <?php endif; ?>
                                            autocomplete="price_sale"
                                            placeholder="Nhập giá tiền (vd:300=300.000đ)"
                                            aria-describedby="price_sale">
                                            <?php $__errorArgs = ['price_sale'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="form-text text-danger"><?php echo e($message, false); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <div class="col-sm-12 col-xl-12 mb-3">
                                            <label for="quantity" class="form-label ">Số lượng <span class="text-danger text-small">(*)</span></label>
                                            <input type="number" name="quantity"
                                            class="form-control 
                                            <?php $__errorArgs = ['quantity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
                                                is-invalid
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                            id="quantity"
                                            <?php if(isset($productVariation)): ?>
                                                value="<?php echo e($productVariation->quantity, false); ?>"
                                            <?php else: ?>
                                                value="<?php echo e(old('quantity'), false); ?>"
                                            <?php endif; ?>
                                            autocomplete="quantity"
                                            placeholder="Nhập số lượng sản phẩm"
                                            aria-describedby="quantity">
                                            <?php $__errorArgs = ['quantity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="form-text text-danger"><?php echo e($message, false); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <div class="col-sm-12 col-xl-12 mb-3">
                                            <label for="position" class="form-label ">Vị trí (Mặc định là 1)</label>
                                            <input type="number" name="position"
                                            class="form-control 
                                            <?php $__errorArgs = ['position'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
                                                is-invalid
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                            id="position"
                                            <?php if(isset($productVariation)): ?>
                                                value="<?php echo e($productVariation->position, false); ?>"
                                            <?php else: ?>
                                                value="1"
                                            <?php endif; ?>
                                            autocomplete="position"
                                            placeholder="Nhập số lượng sản phẩm"
                                            aria-describedby="position">
                                            <?php $__errorArgs = ['position'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="form-text text-danger"><?php echo e($message, false); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <?php if(isset($productVariation)): ?>
                                            <div class="col-sm-12 col-xl-12 mb-3">
                                                <img src="<?php echo e($productVariation->image_url, false); ?>" class="img-fluid" width="200" alt="">
                                            </div>
                                        <?php endif; ?>
                                        <div class="col-sm-12 col-xl-12 mb-3">
                                            <label for="image_url" class="form-label">Chọn hình ảnh <span class="text-danger text-small">(*)</span></label>
                                            <input type="file" name="image_url" class="form-control 
                                            <?php $__errorArgs = ['image_url'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
                                                is-invalid
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                            id="image_url"
                                            aria-describedby="image_url">
                                            <?php $__errorArgs = ['image_url'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="form-text text-danger"><?php echo e($message, false); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <div class="col-sm-12 col-xl-12 mb-3">
                                            <label for="show_hide" class="form-label">Trạng thái (mặc định sẽ là Hiện)</label>
                                            <select class="form-select" name="show_hide" 
                                            <?php if(isset($productVariation)): ?>
                                                value="<?php echo e($productVariation->show_hide, false); ?>"
                                            <?php else: ?>
                                                value="<?php echo e(old('show_hide'), false); ?>"    
                                            <?php endif; ?>
                                            autocomplete="show_hide"
                                            id="show_hide">
                                                <option value="1">Hiện</option>
                                                <option value="0">Ẩn</option>
                                            </select>    
                                        </div>
                                        <div class="col-sm-12 col-xl-12 mb-3">
                                            <div class="d-flex justify-content-end">
                                                <?php if(isset($productVariation)): ?>
                                                    <button type="submit" class="btn btn-primary me-2">Sửa</button>
                                                    <a href="<?php echo e(route('varia.create',['id'=>$product->id]), false); ?>">
                                                        <button type="button" class="float-right btn btn-secondary me-2">Đóng</button>
                                                    </a>                                            
                                                <?php else: ?>
                                                    <?php if($productVariationCount > 0): ?>
                                                        <a href="<?php echo e(route('specifi.create',['id'=>$product->id]), false); ?>">
                                                            <button type="button" class="float-right btn btn-sm btn-secondary me-2">Tiếp theo</button>
                                                        </a>      
                                                        <a href="<?php echo e(route('product.index'), false); ?>">
                                                            <button type="button" class="float-right btn btn-sm btn-secondary me-2">Đóng</button>
                                                        </a> 
                                                    <?php endif; ?>
                                                    <button type="submit" class="btn  <?php if($productVariationCount > 0): ?> btn-sm <?php endif; ?> btn-primary me-2">Thêm</button>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                        <div class="col-sm-12 col-xl-8">
                            <div class="bg-white rounded h-100 p-2 text-start">
                                <div class="table-responsive">
                                    <table class="table table-striped table-hover">
                                        <thead>
                                            <tr>
                                                <th scope="col">Hình ảnh</th>
                                                <th scope="col">Màu sắc</th>
                                                <th scope="col">Giá</th>
                                                <th scope="col">Giá khuyến mãi</th>
                                                <th scope="col">Số lượng</th>
                                                <th scope="col" class="text-start" colspan="2">Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php if(isset($productVariations)): ?>
                                                <?php $__currentLoopData = $productVariations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $variation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr>
                                                        <td><img src="<?php echo e($variation->image_url, false); ?>" class="rounded-3 me-2" width="100" height="100" aria-describedby="image_url"></td>
                                                        <td ><p><?php echo e($variation->color_type, false); ?></p></td>
                                                        <td ><p><?php echo e(number_format($variation->price,0,2), false); ?><span class="text-sm">đ</span></p></td>
                                                        <td ><p><?php echo e(number_format($variation->price_sale,0,2), false); ?><span class="text-sm">đ</span></p></td>
                                                        <td ><p><?php echo e($variation->quantity, false); ?><span class="text-sm"> chiếc</span></p></p></td>
                                                        <td>
                                                            <div class="d-flex justify-content-evenly">
                                                                <a href="<?php echo e(route('varia.edit', ['id'=>$variation->id]), false); ?>" class="
                                                                    <?php if(isset($productVariation)): ?>
                                                                        <?php echo e($productVariation->id == $variation->id ? 'd-none' : '', false); ?>

                                                                    <?php endif; ?>"
                                                                     title="Edit">
                                                                    <button class="btn btn-sm btn-primary">Edit</button>
                                                                </a>
                                                                <form action="<?php echo e(route('varia.delete', ['id' =>$variation->id]), false); ?>" method="POST">
                                                                    <?php echo csrf_field(); ?>
                                                                    <?php echo method_field('delete'); ?>
                                                                    <button class="btn btn-sm btn-danger" type="submit" title="Xóa">Xóa</button>
                                                                </form>
                                                            </div>
                                                        </td>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php else: ?>
                                                <thead>
                                                    <tr>
                                                        <th scope="col">Hình ảnh</th>
                                                        <th scope="col">Màu sắc</th>
                                                        <th scope="col">Giá</th>
                                                        <th scope="col">Giá khuyến mãi</th>
                                                        <th scope="col">Số lượng</th>
                                                        <th scope="col" class="text-start" colspan="2">Action</th>
                                                        <hr>
                                                    </tr>
                                                </thead>
                                            <?php endif; ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Do Trong Nhan\Downloads\datn_laziStore_BE_new\datn_laziStore_BE\resources\views/layouts/admin/components/variaModal.blade.php ENDPATH**/ ?>